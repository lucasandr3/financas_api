<?php

namespace App\Helpers;

class Constants
{
    // comparacao
    const ZERO = 0;

    // parcelamento
    const PARCELADO = 1;
    const SEM_PARCELA = 0;
    const PARCELADO_STRING = 'Parcelado';
    const SEM_PARCELA_STRING = 'Pagamento único';

}
