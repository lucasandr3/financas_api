<?php

const RELATED_EXPENSE = 0;
